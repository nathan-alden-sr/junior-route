﻿using Junior.Route.AspNetIntegration;

namespace $safeprojectname$
{
	public static class JuniorRoute
	{
		public static void Start()
		{
			JuniorRouteApplication.RegisterConfiguration<JuniorRouteConfiguration>();
		}
	}
}
﻿using System.Web;

using Junior.Route.AspNetIntegration;

namespace $safeprojectname$
{
	public class Global : HttpApplication
	{
		public Global()
		{
			JuniorRouteApplication.AttachToHttpApplication(this);
		}
	}
}